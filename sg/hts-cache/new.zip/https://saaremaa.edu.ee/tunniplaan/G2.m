<!DOCTYPE html>
<html class="no-js" lang="et">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="apple-touch-icon" sizes="180x180" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon//favicon-16x16.png">
    <link rel="manifest" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/manifest.json">
    <link rel="mask-icon" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/safari-pinned-tab.svg" color="#ffffff">
    <link rel="shortcut icon" href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/favicon.ico">
    <meta name="msapplication-config" content="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <script>(function(H){H.className=H.className.replace(/\bno-js\b/,'js')})(document.documentElement)</script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&display=swap" rel="stylesheet">
            <meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v27.1.1 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<title>Page not found - Saaremaa G&uuml;mnaasium</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Saaremaa G&uuml;mnaasium" />
	<meta property="og:site_name" content="Saaremaa G&uuml;mnaasium" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://saaremaa.edu.ee/#website","url":"https://saaremaa.edu.ee/","name":"Saaremaa G&uuml;mnaasium","description":"","publisher":{"@id":"https://saaremaa.edu.ee/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://saaremaa.edu.ee/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en"},{"@type":"Organization","@id":"https://saaremaa.edu.ee/#organization","name":"Saaremaa Gümnaasium","url":"https://saaremaa.edu.ee/","logo":{"@type":"ImageObject","inLanguage":"en","@id":"https://saaremaa.edu.ee/#/schema/logo/image/","url":"https://saaremaa.edu.ee/wp-content/uploads/2021/05/saaremaa-gumnaasium-facebook-post-image3x.png","contentUrl":"https://saaremaa.edu.ee/wp-content/uploads/2021/05/saaremaa-gumnaasium-facebook-post-image3x.png","width":2460,"height":1386,"caption":"Saaremaa Gümnaasium"},"image":{"@id":"https://saaremaa.edu.ee/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/saaremaagymn","https://www.instagram.com/saaremaagymnaasium","https://www.youtube.com/channel/UCv7LvtZn5WJ9gF80YIa_Rfw"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<style id='wp-img-auto-sizes-contain-inline-css' type='text/css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='jquery-css' href='https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/css/jquery.cf4a0c466da5bbec86b7.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='global-css' href='https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/css/global.1f383b272a1b12e76d87.min.css' type='text/css' media='all' />

    
    </head>
<body class="error404 wp-theme-saaremaa-gymnaasium">
    <div id="page">
                    <header class="header  has-notice">
            <div class="header__notice-container">
            <div class="header-notice header__notice ">
    <div class="h-container text-small">
        <span class="header-notice__text"></span>
                    <a class="header-notice__button" href="https://forms.office.com/pages/responsepage.aspx?id=BjY735_Vl0KI8fXkv3wVMrTOGYRtWfxKp85eCGEs9etURFMwOFMyNzNaR01JUzhKSlc5UDA1WjZQOS4u&route=shorturl">Tunnusta Saaremaa Gümnaasiumi töötajat!<svg class="icon  header-notice__icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-inverted"></use>
</svg>
            </a>
            </div>
</div>
        </div>
        <div class="h-container header__container">
        <div class="header__main">
            
<div class="logo  header__logo">
            <a href="https://saaremaa.edu.ee" class="logo__link">
                <span class="logo__content">
        <img
            class="logo__image"
            alt="logo-image"
            src="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/img/logo.svg"
        >
    </span>

        </a>
    </div>
            <button
                type="button"
                class="header__toggle"
                aria-label="Menu"
                aria-expanded="false"
            >
                <svg class="icon  header__toggle-icon header__toggle-icon--open" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#menu"></use>
</svg>
                <svg class="icon  header__toggle-icon header__toggle-icon--close" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#close"></use>
</svg>
            </button>
        </div>
        <div class="header__inner" tabindex="-1">
                            <nav class="megamenu  header__megamenu">
    <ul class="megamenu__list">
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/">
                    Avaleht
                                    </a>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/uudised/">
                    Uudised
                                    </a>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/sundmused/">
                    Sündmused
                                    </a>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/koolielu/">
                    Koolielu
                                    </a>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/tule-oppima/">
                    Tule õppima
                                    </a>
                            </li>
                    <li class="megamenu__item has-children">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/">
                    Koolist
                                            <svg class="icon  megamenu__main-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-bottom"></use>
</svg>
                                    </a>
                                    <div class="megamenu__container">
                        <div class="megamenu__container-inner">
                            <a class="megamenu__inner-link h3" href="https://saaremaa.edu.ee/koolist/" tabindex="-1">
                                Koolist
                                <svg class="icon  megamenu__inner-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                            </a>
                            <ul class="megamenu__list megamenu__list--child">
                                                                    <li class="megamenu__item megamenu__item--child">
                                                                                    <p class="megamenu__child-title">Üldine</p>
                                                                                                                            <ul class="megamenu__list megamenu__list--grandchild">
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/" data-image="2958" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Ülevaade
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/meie-inimesed/" data-image="53" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Meie inimesed
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/teenused/" data-image="57" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Teenused
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/opikasitus/" data-image="326" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Õpikäsitus
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                            </ul>
                                                                            </li>
                                                                    <li class="megamenu__item megamenu__item--child">
                                                                                    <p class="megamenu__child-title">Dokumendid</p>
                                                                                                                            <ul class="megamenu__list megamenu__list--grandchild">
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/dokumendid/" data-image="52" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Dokumendid
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/blanketid/" data-image="51" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Blanketid
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/projektid/" data-image="54" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Projektid
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                            </ul>
                                                                            </li>
                                                                    <li class="megamenu__item megamenu__item--child">
                                                                                    <p class="megamenu__child-title">Huvitavat</p>
                                                                                                                            <ul class="megamenu__list megamenu__list--grandchild">
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/galeriid/" data-image="62" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Galerii
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/sumboolika/" data-image="3896" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Sümboolika
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/vilistlaskogu/" data-image="7129" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Vilistlaskogu
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/koolist/saaremaa-gumnaasiumi-sund/" data-image="55" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Saaremaa Gümnaasiumi sünd
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://norrison.ee/et/942-saaremaa-gumnaasium" data-image="5796" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Norrison e-pood
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/haridusuuenduskonverents/" data-image="10097" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Haridusuuenduskonverents
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/mottekaardid/" data-image="7492" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Mõttekaardid
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                                    <li class="megamenu__item megamenu__item--grandchild">
                                                        <a class="megamenu__link" href="https://saaremaa.edu.ee/riigigumnaasiumide-rahvatantsufestival/" data-image="9179" tabindex="-1">
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                            Riigigümnaasiumide rahvatantsufestival
                                                            <svg class="icon  megamenu__chevron megamenu__chevron--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                                        </a>
                                                    </li>
                                                                                            </ul>
                                                                            </li>
                                                            </ul>
                            <div class="megamenu__visuals">
                                                                                                            <div class="megamenu__image-container" id="2958">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="53">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="57">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="326">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                                                                                                <div class="megamenu__image-container" id="52">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="51">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="54">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                                                                                                <div class="megamenu__image-container" id="62">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20290%20190%22%3E%3C%2Fsvg%3E"
        data-srcset="https://saaremaa.edu.ee/wp-content/uploads/2021/04/nurgakivi_9-290x190.jpg 290w, https://saaremaa.edu.ee/wp-content/uploads/2021/04/nurgakivi_9-580x380.jpg 580w"
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="3896">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="7129">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="55">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="5796">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="10097">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="7492">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                            <div class="megamenu__image-container" id="9179">
                                            <figure class="image  megamenu__image">
                            <img
        loading="lazy"
        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
        data-srcset=""
        data-sizes="auto"
        alt=""
                        class="image__img lazyload"
    >

    
        </figure>
                                        </div>
                                                                                                </div>
                        </div>
                    </div>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/oppetoo/">
                    Õppetöö
                                    </a>
                            </li>
                    <li class="megamenu__item">
                <a class="megamenu__link" href="https://saaremaa.edu.ee/kontakt/">
                    Kontakt
                                    </a>
                            </li>
            </ul>
</nav>
                                        <div class="references  header__references">
            <form class="references__search-form" method="GET" action="https://saaremaa.edu.ee">
            <div class="references__search-field">
                <label class="h-hidden" for="search-field">Otsing</label>
                <input
                    class="references__search-input"
                    type="text"
                    id="search-field"
                    name="s"
                    placeholder="Otsing"
                >
                <svg class="icon  references__search-form-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#search"></use>
</svg>
                

<button
     type="submit"     class="button references__search-button button--icon">
    <span class="button__inner">
                    <span class="button__icon-container">
                                <svg class="icon  button__icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#search"></use>
</svg>
            </span>
                <span class="button__text">otsing</span>
        <span class="button__bubble"><span class="button__bubble-inner"></span></span>
    </span>
        </button>
            </div>
        </form>
        <button class="references__search-trigger references__item js-search-trigger" type="button">
            <svg class="icon  references__search-trigger-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#search"></use>
</svg>
            Otsing
        </button>
                                            <div class="dropdown  references__item">
    <button class="dropdown__button js-dropdown-trigger" type="button">
        Kiirviited
        <svg class="icon  dropdown__chevron dropdown__chevron--desktop" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-small-16x16"></use>
</svg>
        <svg class="icon  dropdown__chevron dropdown__chevron--mobile" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-bottom"></use>
</svg>
    </button>
    <ul class="dropdown__list">
                    <li class="dropdown__item">
                <a class="dropdown__link" href="https://www.office.com/" target="_blank">
                    Office 365
                    <div class="dropdown__icon-container">
                        <svg class="icon  dropdown__arrow" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#arrow-right"></use>
</svg>
                    </div>
                </a>
            </li>
                    <li class="dropdown__item">
                <a class="dropdown__link" href="https://www.kooliraamatukogud.ee/?lib=1114" target="_blank">
                    Raamatukogu RIKSWEB
                    <div class="dropdown__icon-container">
                        <svg class="icon  dropdown__arrow" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#arrow-right"></use>
</svg>
                    </div>
                </a>
            </li>
                    <li class="dropdown__item">
                <a class="dropdown__link" href="https://www.riigitootaja.ee/rtip-client/login" target="_blank">
                    RTIP
                    <div class="dropdown__icon-container">
                        <svg class="icon  dropdown__arrow" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#arrow-right"></use>
</svg>
                    </div>
                </a>
            </li>
                    <li class="dropdown__item">
                <a class="dropdown__link" href="https://adr.pinal.edu.ee/et/?orgId=6" target="_self">
                    PINAL
                    <div class="dropdown__icon-container">
                        <svg class="icon  dropdown__arrow" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#arrow-right"></use>
</svg>
                    </div>
                </a>
            </li>
            </ul>
</div>
                                                <a class="references__link references__item" href="https://saaremaagymnaasium.ope.ee">
                    Stuudium
                    <svg class="icon  references__chevron references__chevron--desktop" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-small-16x16"></use>
</svg>
                    <svg class="icon  references__chevron references__chevron--mobile" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right"></use>
</svg>
                </a>
                            </div>
                    </div>
    </div>
</header>
<main class="main">
                    


<div class="section section--top-large section--bottom-large not-found">
            <div class="section__container h-container">
            <div class="grid grid--center-xs">
                <div class="    grid__col grid__col--xs-4 grid__col--md-10 grid__col--lg-8">
                            <div class="section__content">
            <div class="text text-center">
                    <h1 class="h2">Lehekülge ei leitud.</h1>
                            <p class="not-found__description text-large">Soovitud lehte sisestatud aadressiga ei leitud.</p>
                            

<a
     href="https://saaremaa.edu.ee"    class="button not-found__button">
    <span class="button__inner">
                <span class="button__text">Tagasi avalehele</span>
        <span class="button__bubble"><span class="button__bubble-inner"></span></span>
    </span>
        </a>
            </div>

    </div>

                </div>
            </div>
        </div>
    </div>
    
</main>
<footer class="footer">
    <div class="footer__background">
        <svg class="footer__svg" width="100%" height="100%" fill="#ffffff" focusable="false" viewBox="0 0 297 348" xmlns="http://www.w3.org/2000/svg">
            <path opacity=".1" d="M119.003,0.307C53.297,0.307,0,52.873,0,117.676V348H177.997C243.703,348,297,295.435,297,230.631V227.22V225.014V0.308H119.003ZM48.212,54.277C62.044000000000004,42.841,79.946,37.022999999999996,100.492,37.022999999999996C103.747,37.022999999999996,107.205,37.223,110.66300000000001,37.424C152.162,41.236,196.71200000000002,67.318,230.073,107.043C236.99,115.46900000000001,243.29600000000002,124.096,248.788,132.924C229.056,118.47900000000001,204.442,109.852,177.997,109.852H19.936C22.58,87.18,31.938,67.719,48.212,54.277ZM19.325,328.94V202.944C27.665,220.6,38.650999999999996,237.653,52.077,253.503C86.65899999999999,294.83299999999997,132.836,322.52,176.97899999999998,329.14099999999996H19.325V328.93999999999994ZM248.78799999999998,294.03C232.51399999999998,307.272,210.95099999999996,313.09,186.337,310.883C144.838,307.07099999999997,100.28799999999998,280.989,66.92699999999999,241.265C60.00999999999999,232.838,53.70399999999999,224.21099999999998,48.21199999999999,215.38299999999998C67.94399999999999,229.82899999999998,92.55799999999999,238.456,119.00299999999999,238.456H277.06399999999996C274.41999999999996,261.127,265.26599999999996,280.789,248.78799999999995,294.03ZM119.00299999999999,219.39599999999996C66.72299999999998,219.39599999999996,23.800999999999988,179.46999999999997,19.73299999999999,128.91099999999994H178.2C230.48,128.91099999999994,273.403,168.83699999999993,277.471,219.39599999999996H119.003ZM277.67499999999995,145.56399999999996C269.33399999999995,127.90799999999996,258.34899999999993,110.85499999999996,244.92299999999994,95.00499999999997C210.54499999999996,53.874999999999964,164.57099999999994,25.98799999999997,120.42699999999995,19.366999999999962H277.67499999999995V145.56399999999996Z" />
        </svg>
    </div>
    <div class="h-container">
        <div class="grid">
            <div class="grid__col grid__col--xs-4 grid__col--sm-2 grid__col--md-4">
                
<div class="logo  footer__logo">
            <a href="https://saaremaa.edu.ee" class="logo__link">
                <span class="logo__content">
        <img
            class="logo__image"
            alt="logo-image"
            src="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/img/logo.svg"
        >
    </span>

        </a>
    </div>
                                    <div class="footer__content text">
                        <p>Saaremaa Gümnaasium</p>
<p>Reg nr. 77001263</p>
<p>Väljaku tn 8<br />
Kuressaare linn, Saaremaa vald<br />
Saare maakond 93811</p>

                    </div>
                            </div>
                            <div class="grid__col grid__col--xs-4 grid__col--sm-2 grid__col--md-8 grid__col--xl-6">
                                            


<nav class="navigation navigation--vertical footer__navigation" aria-label="Jalusemenüü">
            <ul class="navigation__list">
                            <li class="navigation__item  has-children menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-70">
                    <a href="https://saaremaa.edu.ee/kontakt/" class="navigation__link" target="_self">Kontaktid</a>
                                            <svg class="icon  navigation__chevron" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-bottom"></use>
</svg>
                        <ul class="navigation__list navigation__list--child">
                                                                                                                                                            <li class="navigation__item ">
                                                <noscript><span style="unicode-bidi:bidi-override;direction:rtl;">ee.ude.aameraas@ofni</span></noscript><script type="text/javascript">var element = document.createElement('div'); element.innerHTML = '<n uers="znvygb:vasb@fnnerznn.rqh.rr" pynff="anivtngvba__yvax" gnetrg="_frys">vasb@fnnerznn.rqh.rr</n>'.replace(/[a-zA-Z]/g, function(c){return String.fromCharCode((c<="Z"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26);});document.currentScript.replaceWith(...element.childNodes);</script>

                                </li>
                                                                                                                                                            <li class="navigation__item ">
                                                <a href="tel:+37256501878" class="navigation__link" target="_self">+372 5650 1878</a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://saaremaa.edu.ee/toopakkumised/" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Tööpakkumised                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                    </ul>
                                    </li>
                            <li class="navigation__item  has-children menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-71">
                    <a href="#" class="navigation__link" target="_self">Töövahendid</a>
                                            <svg class="icon  navigation__chevron" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-bottom"></use>
</svg>
                        <ul class="navigation__list navigation__list--child">
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://saaremaa.edu.ee/koolist/dokumendid/" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Dokumendid                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://saaremaa.edu.ee/koolist/blanketid/" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Blanketid                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                    </ul>
                                    </li>
                            <li class="navigation__item  has-children menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-72">
                    <a href="#" class="navigation__link" target="_self">Kiirviited</a>
                                            <svg class="icon  navigation__chevron" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-bottom"></use>
</svg>
                        <ul class="navigation__list navigation__list--child">
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://saaremaagymnaasium.ope.ee" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Stuudium                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://www.office.com/" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Office 365                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://www.kooliraamatukogud.ee/?lib=1114" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    Raamatukogu RIKSWEB                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://www.riigitootaja.ee/rtip-client/login" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    RTIP                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                                                                                                                                                                                                                                    <li class="navigation__item ">
                                                <a href="https://adr.pinal.edu.ee/et/?orgId=6" class="navigation__link" target="_self">                                        <svg class="icon  navigation__icon navigation__icon--left" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    PINAL                                        <svg class="icon  navigation__icon navigation__icon--right" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#chevron-right-16x16"></use>
</svg>
                                    </a>

                                </li>
                                                    </ul>
                                    </li>
                    </ul>
    </nav>
                                    </div>
                                        <div class="grid__col grid__col--xs-4 grid__col--xl-2">
                    <span class="footer__social-title text-large">Sotsiaalmeedia</span>
                    <nav class="footer__social" aria-label="Sotsiaalmeedia">
                        <ul class="footer__social-list">
                                                            <li class="footer__social-item">
                                    <a href="https://www.linkedin.com/company/saaremaa-g%C3%BCmnaasium/" target="_blank" class="footer__social-link">
                                        <svg class="icon  footer__social-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#social-linkedin"></use>
</svg>
                                        <span class="footer__social-label">LinkedIn</span>
                                    </a>
                                </li>
                                                            <li class="footer__social-item">
                                    <a href="https://www.facebook.com/saaremaagymn" target="_blank" class="footer__social-link">
                                        <svg class="icon  footer__social-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#social-facebook"></use>
</svg>
                                        <span class="footer__social-label">Facebook</span>
                                    </a>
                                </li>
                                                            <li class="footer__social-item">
                                    <a href="https://www.instagram.com/saaremaagymnaasium/" target="_blank" class="footer__social-link">
                                        <svg class="icon  footer__social-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#social-instagram"></use>
</svg>
                                        <span class="footer__social-label">Instagram</span>
                                    </a>
                                </li>
                                                            <li class="footer__social-item">
                                    <a href="https://www.youtube.com/channel/UCv7LvtZn5WJ9gF80YIa_Rfw" target="_blank" class="footer__social-link">
                                        <svg class="icon  footer__social-icon" focusable="false">
    <use xlink:href="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg#social-youtube"></use>
</svg>
                                        <span class="footer__social-label">Youtube</span>
                                    </a>
                                </li>
                                                    </ul>
                    </nav>
                </div>
                    </div>
                    <hr class="footer__hr">
            <div class="grid">
                <div class="grid__col grid__col--xs-4 grid__col--md-12 footer__bottom">
                                            <div class="footer__copyright"><p>2026 © Kõik õigused kaitstud.</p>
</div>
                                                                


<nav class="navigation navigation--clean footer__secondary-navigation" aria-label="Jaluse lisamenüü">
            <ul class="navigation__list">
                            <li class="navigation__item  menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-94">
                    <a href="https://saaremaa.edu.ee/privaatsuspoliitika-ja-kupsised/" class="navigation__link" target="_self">Privaatsuspoliitika ja küpsised</a>
                                    </li>
                    </ul>
    </nav>
                                    </div>
            </div>
            </div>
</footer>
<div class="notification-list"></div>

            </div>

            <script type="text/javascript" id="rocket-browser-checker-js-after">
/* <![CDATA[ */
"use strict";var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||!1,descriptor.configurable=!0,"value"in descriptor&&(descriptor.writable=!0),Object.defineProperty(target,descriptor.key,descriptor)}}return function(Constructor,protoProps,staticProps){return protoProps&&defineProperties(Constructor.prototype,protoProps),staticProps&&defineProperties(Constructor,staticProps),Constructor}}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor))throw new TypeError("Cannot call a class as a function")}var RocketBrowserCompatibilityChecker=function(){function RocketBrowserCompatibilityChecker(options){_classCallCheck(this,RocketBrowserCompatibilityChecker),this.passiveSupported=!1,this._checkPassiveOption(this),this.options=!!this.passiveSupported&&options}return _createClass(RocketBrowserCompatibilityChecker,[{key:"_checkPassiveOption",value:function(self){try{var options={get passive(){return!(self.passiveSupported=!0)}};window.addEventListener("test",null,options),window.removeEventListener("test",null,options)}catch(err){self.passiveSupported=!1}}},{key:"initRequestIdleCallback",value:function(){!1 in window&&(window.requestIdleCallback=function(cb){var start=Date.now();return setTimeout(function(){cb({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-start))}})},1)}),!1 in window&&(window.cancelIdleCallback=function(id){return clearTimeout(id)})}},{key:"isDataSaverModeOn",value:function(){return"connection"in navigator&&!0===navigator.connection.saveData}},{key:"supportsLinkPrefetch",value:function(){var elem=document.createElement("link");return elem.relList&&elem.relList.supports&&elem.relList.supports("prefetch")&&window.IntersectionObserver&&"isIntersecting"in IntersectionObserverEntry.prototype}},{key:"isSlowConnection",value:function(){return"connection"in navigator&&"effectiveType"in navigator.connection&&("2g"===navigator.connection.effectiveType||"slow-2g"===navigator.connection.effectiveType)}}]),RocketBrowserCompatibilityChecker}();
//# sourceURL=rocket-browser-checker-js-after
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-extra">
/* <![CDATA[ */
var RocketPreloadLinksConfig = {"excludeUris":"/(?:.+/)?feed(?:/(?:.+/?)?)?$|/(?:.+/)?embed/|/(index.php/)?(.*)wp-json(/.*|$)|/refer/|/go/|/recommend/|/recommends/","usesTrailingSlash":"","imageExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php","fileExt":"jpg|jpeg|gif|png|tiff|bmp|webp|avif|pdf|doc|docx|xls|xlsx|php|html|htm","siteUrl":"https://saaremaa.edu.ee","onHoverDelay":"100","rateThrottle":"3"};
//# sourceURL=rocket-preload-links-js-extra
/* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-after">
/* <![CDATA[ */
(function() {
"use strict";var r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},e=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}();function i(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}var t=function(){function n(e,t){i(this,n),this.browser=e,this.config=t,this.options=this.browser.options,this.prefetched=new Set,this.eventTime=null,this.threshold=1111,this.numOnHover=0}return e(n,[{key:"init",value:function(){!this.browser.supportsLinkPrefetch()||this.browser.isDataSaverModeOn()||this.browser.isSlowConnection()||(this.regex={excludeUris:RegExp(this.config.excludeUris,"i"),images:RegExp(".("+this.config.imageExt+")$","i"),fileExt:RegExp(".("+this.config.fileExt+")$","i")},this._initListeners(this))}},{key:"_initListeners",value:function(e){-1<this.config.onHoverDelay&&document.addEventListener("mouseover",e.listener.bind(e),e.listenerOptions),document.addEventListener("mousedown",e.listener.bind(e),e.listenerOptions),document.addEventListener("touchstart",e.listener.bind(e),e.listenerOptions)}},{key:"listener",value:function(e){var t=e.target.closest("a"),n=this._prepareUrl(t);if(null!==n)switch(e.type){case"mousedown":case"touchstart":this._addPrefetchLink(n);break;case"mouseover":this._earlyPrefetch(t,n,"mouseout")}}},{key:"_earlyPrefetch",value:function(t,e,n){var i=this,r=setTimeout(function(){if(r=null,0===i.numOnHover)setTimeout(function(){return i.numOnHover=0},1e3);else if(i.numOnHover>i.config.rateThrottle)return;i.numOnHover++,i._addPrefetchLink(e)},this.config.onHoverDelay);t.addEventListener(n,function e(){t.removeEventListener(n,e,{passive:!0}),null!==r&&(clearTimeout(r),r=null)},{passive:!0})}},{key:"_addPrefetchLink",value:function(i){return this.prefetched.add(i.href),new Promise(function(e,t){var n=document.createElement("link");n.rel="prefetch",n.href=i.href,n.onload=e,n.onerror=t,document.head.appendChild(n)}).catch(function(){})}},{key:"_prepareUrl",value:function(e){if(null===e||"object"!==(void 0===e?"undefined":r(e))||!1 in e||-1===["http:","https:"].indexOf(e.protocol))return null;var t=e.href.substring(0,this.config.siteUrl.length),n=this._getPathname(e.href,t),i={original:e.href,protocol:e.protocol,origin:t,pathname:n,href:t+n};return this._isLinkOk(i)?i:null}},{key:"_getPathname",value:function(e,t){var n=t?e.substring(this.config.siteUrl.length):e;return n.startsWith("/")||(n="/"+n),this._shouldAddTrailingSlash(n)?n+"/":n}},{key:"_shouldAddTrailingSlash",value:function(e){return this.config.usesTrailingSlash&&!e.endsWith("/")&&!this.regex.fileExt.test(e)}},{key:"_isLinkOk",value:function(e){return null!==e&&"object"===(void 0===e?"undefined":r(e))&&(!this.prefetched.has(e.href)&&e.origin===this.config.siteUrl&&-1===e.href.indexOf("?")&&-1===e.href.indexOf("#")&&!this.regex.excludeUris.test(e.href)&&!this.regex.images.test(e.href))}}],[{key:"run",value:function(){"undefined"!=typeof RocketPreloadLinksConfig&&new n(new RocketBrowserCompatibilityChecker({capture:!0,passive:!0}),RocketPreloadLinksConfig).init()}}]),n}();t.run();
}());

//# sourceURL=rocket-preload-links-js-after
/* ]]> */
</script>
<script type="text/javascript" id="core-js-extra">
/* <![CDATA[ */
var gotoAndPlay = {"version":"420","nonce":"b5ede67046","assetsPath":"https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/","templatePath":"https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/","svgPath":"https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/svg/global.2ca9f0742cb2e2b900ad4dcceec60412.svg","loggedIn":"","cookiePath":"/","cookieDomain":"saaremaa.edu.ee","ajaxPath":"https://saaremaa.edu.ee/wp-admin/admin-ajax.php","ajax":{"isEnabled":false,"keptBodyClasses":[],"templateName":"404"},"googleMapsApiKey":"AIzaSyBfMRFKFNkQsZYa7l-hAbq-iGIoM3S4D0s","sitePath":"https://saaremaa.edu.ee/","notifications":[{"component":"BrowserNotification","data":{"content":"Kasutate vananenud brauserit. Parema kasutuskogemuse ja turvalisuse huvides palun kasutage uuemat brauserit.","customActions":[{"link":"https://browsehappy.com/","text":"Loe juurde","attributes":"target=\"_blank\""}],"button":{"text":"Ignoreeri"}}},{"component":"CookieNotification","data":{"content":"\u003Cp\u003EVeebilehe kasutamist j\u00e4tkates n\u00f5ustute k\u00fcpsiste kasutamisega. \u003Ca href=\"https://saaremaa.edu.ee/privaatsuspoliitika-ja-kupsised/\"\u003ELoe l\u00e4hemalt\u003C/a\u003E.\u003C/p\u003E\n","button":{"text":"Sulge teavitus"}}}]};
//# sourceURL=core-js-extra
/* ]]> */
</script>
<script type="text/javascript" src="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/js/core.c35db26cf089e6fa8467.min.js" id="core-js"></script>
<script type="text/javascript" src="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/js/jquery.2e85c99c27b4dbbb0cc9.min.js" id="webpack-jquery-js"></script>
<script type="text/javascript" src="https://saaremaa.edu.ee/wp-content/themes/saaremaa-gymnaasium/inc/theme/js/global.1d55cd03fd9d0e63ce02.min.js" id="jquery-js"></script>
<script type="text/javascript" src="https://saaremaa.edu.ee/wp-includes/js/jquery/jquery-migrate.min.js" id="jquery-migrate-js"></script>
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/saaremaa-gymnaasium/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>

    </body>
</html>
